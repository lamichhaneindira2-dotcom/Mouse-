package com.example.mousehunter;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.task.vision.detector.Detection;
import org.tensorflow.lite.task.vision.detector.ObjectDetector;
import org.tensorflow.lite.task.vision.detector.ObjectDetector.ObjectDetectorOptions;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Mouse Hunter: camera-based visible-object demo. Wall vision is explicitly simulated. */
public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private TextView status;
    private Button invertButton, wallButton, sensorButton;
    private boolean invertEnabled = true, wallMode = false, sensorMode = false;
    private ExecutorService cameraExecutor;
    private ObjectDetector detector;
    private volatile boolean analyzing = false;
    private final ActivityResultLauncher<String> cameraPermission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) startCamera(); else status.setText("Camera permission is needed for live detection.");
            });

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        cameraExecutor = Executors.newSingleThreadExecutor();
        buildUi();
        status.setText("Preparing AI model… first launch needs internet to download it.");
        loadDetectorInBackground();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera();
        else cameraPermission.launch(Manifest.permission.CAMERA);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(18)); root.setBackgroundColor(Color.rgb(7,17,28));
        scroll.addView(root);
        TextView title = new TextView(this); title.setText("MOUSE HUNTER"); title.setTextColor(Color.rgb(69,230,168));
        title.setTextSize(25); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());
        TextView subtitle = new TextView(this); subtitle.setText("Visible mouse detection • local camera preview"); subtitle.setTextColor(Color.LTGRAY); subtitle.setGravity(Gravity.CENTER); subtitle.setTextSize(13);
        root.addView(subtitle, matchWrap());
        FrameLayout frame = new FrameLayout(this); frame.setBackgroundColor(Color.BLACK);
        imageView = new ImageView(this); imageView.setScaleType(ImageView.ScaleType.FIT_CENTER); imageView.setBackgroundColor(Color.BLACK);
        frame.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(410)); fp.topMargin = dp(14); root.addView(frame, fp);
        status = new TextView(this); status.setTextColor(Color.WHITE); status.setTextSize(14); status.setPadding(dp(4),dp(12),dp(4),dp(8)); root.addView(status, matchWrap());
        invertButton = makeButton("Mouse-only inversion: ON"); invertButton.setOnClickListener(v -> { invertEnabled = !invertEnabled; invertButton.setText("Mouse-only inversion: " + (invertEnabled ? "ON" : "OFF")); }); root.addView(invertButton, matchWrap());
        wallButton = makeButton("Simulated wall vision: OFF"); wallButton.setOnClickListener(v -> { wallMode = !wallMode; wallButton.setText("Simulated wall vision: " + (wallMode ? "ON" : "OFF")); status.setText(wallMode ? "SIMULATION ONLY: this is a visual demo, not a real reading through the wall." : "Wall simulation off. Live camera mode selected."); renderWallDemo(); });
        LinearLayout.LayoutParams bp = matchWrap(); bp.topMargin = dp(8); root.addView(wallButton, bp);
        sensorButton = makeButton("External sensor: NOT CONNECTED"); sensorButton.setOnClickListener(v -> { sensorMode = !sensorMode; sensorButton.setText(sensorMode ? "External sensor: DEMO MODE" : "External sensor: NOT CONNECTED"); Toast.makeText(this, "A compatible sensor and its connection protocol are required. This button does not connect hardware.", Toast.LENGTH_LONG).show(); });
        bp = matchWrap(); bp.topMargin = dp(8); root.addView(sensorButton, bp);
        TextView note = new TextView(this); note.setText("Reality check: a phone camera cannot see through solid walls. Color inversion is not thermal vision. AI works only if the model recognizes a mouse in the visible frame."); note.setTextColor(Color.rgb(255,204,102)); note.setTextSize(12); note.setPadding(dp(4),dp(12),dp(4),dp(4)); root.addView(note, matchWrap());
        setContentView(scroll);
    }

    private Button makeButton(String label) { Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(25,47,64))); return b; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }


    private void loadDetectorInBackground() {
        new Thread(() -> {
            try {
                File modelFile = new File(getFilesDir(), "mouse_detector.tflite");
                if (!modelFile.exists() || modelFile.length() < 100000) {
                    URL url = new URL("https://storage.googleapis.com/download.tensorflow.org/models/tflite/task_library/object_detection/android/lite-model_efficientdet_lite0_detection_metadata_1.tflite");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setConnectTimeout(15000); connection.setReadTimeout(30000); connection.setInstanceFollowRedirects(true);
                    connection.connect();
                    if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) throw new IOException("Model download returned HTTP " + connection.getResponseCode());
                    try (java.io.InputStream in = connection.getInputStream(); FileOutputStream out = new FileOutputStream(modelFile)) {
                        byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                    } finally { connection.disconnect(); }
                }
                byte[] modelBytes;
                try (FileInputStream in = new FileInputStream(modelFile)) { modelBytes = new byte[(int) modelFile.length()]; int offset=0, n; while(offset<modelBytes.length && (n=in.read(modelBytes,offset,modelBytes.length-offset))>0) offset+=n; }
                java.nio.ByteBuffer modelBuffer = java.nio.ByteBuffer.allocateDirect(modelBytes.length);
                modelBuffer.put(modelBytes); modelBuffer.rewind();
                ObjectDetectorOptions options = ObjectDetectorOptions.builder().setMaxResults(10).setScoreThreshold(0.35f).build();
                ObjectDetector loaded = ObjectDetector.createFromBufferAndOptions(modelBuffer, options);
                detector = loaded;
                runOnUiThread(() -> status.setText("AI model ready. Point the camera at the floor or food-storage area."));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("AI model download/load failed. Check internet, restart app, or follow README manual setup."));
            }
        }, "MouseHunterModelLoader").start();
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                ImageAnalysis analysis = new ImageAnalysis.Builder().setTargetResolution(new android.util.Size(640, 480)).setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                analysis.setAnalyzer(cameraExecutor, this::analyzeFrame);
                provider.unbindAll(); provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, analysis);
                // CameraX analysis frames are shown as bitmaps so only detected mouse pixels can be inverted.
                status.setText(detector == null ? "Camera running. Add the model file to enable AI mouse detection." : "Camera running. Looking for a visible mouse…");
            } catch (Exception e) { status.setText("Could not start camera: " + e.getMessage()); }
        }, ContextCompat.getMainExecutor(this));
    }

    private void analyzeFrame(@NonNull ImageProxy image) {
        if (analyzing) { image.close(); return; }
        analyzing = true;
        try {
            Bitmap bitmap = yuvToBitmap(image);
            int rotation = image.getImageInfo().getRotationDegrees();
            if (rotation != 0) {
                android.graphics.Matrix matrix = new android.graphics.Matrix(); matrix.postRotate(rotation);
                Bitmap rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                if (rotated != bitmap) bitmap.recycle(); bitmap = rotated;
            }
            Bitmap output = bitmap.copy(Bitmap.Config.ARGB_8888, true);
            int mouseCount = 0;
            if (detector != null && !wallMode) {
                List<Detection> detections = detector.detect(TensorImage.fromBitmap(bitmap));
                Canvas canvas = new Canvas(output); Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
                paint.setColor(Color.rgb(69,230,168)); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(3f, bitmap.getWidth()/180f));
                Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG); textPaint.setColor(Color.rgb(69,230,168)); textPaint.setTextSize(Math.max(22f, bitmap.getWidth()/22f)); textPaint.setTypeface(Typeface.DEFAULT_BOLD);
                for (Detection d : detections) {
                    boolean mouse = false;
                    for (var c : d.getCategories()) if (c.getLabel() != null && c.getLabel().toLowerCase().contains("mouse")) mouse = true;
                    if (!mouse) continue;
                    mouseCount++;
                    RectF r = new RectF(d.getBoundingBox());
                    if (invertEnabled) invertRegion(output, r);
                    canvas.drawRect(r, paint); canvas.drawText("MOUSE", Math.max(4, r.left), Math.max(26, r.top - 8), textPaint);
                }
            }
            final Bitmap shown = output; final int count = mouseCount; final boolean modelReady = detector != null;
            runOnUiThread(() -> {
                if (!wallMode) imageView.setImageBitmap(shown);
                if (wallMode) renderWallDemo();
                else if (!modelReady) status.setText("Live camera active • AI model missing (see README)");
                else status.setText(count > 0 ? "ALERT: " + count + " visible mouse detection(s)." : "Scanning visible scene… no mouse detected in this frame.");
            });
            if (bitmap != output) bitmap.recycle();
        } catch (Exception e) { runOnUiThread(() -> status.setText("Frame processing error: " + e.getMessage())); }
        finally { image.close(); analyzing = false; }
    }

    private void renderWallDemo() {
        if (!wallMode || imageView == null) return;
        Bitmap b = Bitmap.createBitmap(640, 480, Bitmap.Config.ARGB_8888); Canvas c = new Canvas(b);
        c.drawColor(Color.rgb(65,70,77)); Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.rgb(110,117,124)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); c.drawRect(20,20,620,460,p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(255,204,102)); p.setTextSize(26); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText("SIMULATED WALL VIEW", 55, 70, p);
        p.setColor(Color.rgb(69,230,168)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); c.drawOval(260,180,380,280,p);
        p.setStyle(Paint.Style.FILL); p.setTextSize(20); c.drawText("Possible location (fictional)", 150, 330, p);
        p.setColor(Color.WHITE); p.setTextSize(16); c.drawText("No real sensor data", 220, 370, p); imageView.setImageBitmap(b);
    }

    private void invertRegion(Bitmap bitmap, RectF rect) {
        int left = Math.max(0, (int)rect.left), top = Math.max(0, (int)rect.top);
        int right = Math.min(bitmap.getWidth(), (int)Math.ceil(rect.right)), bottom = Math.min(bitmap.getHeight(), (int)Math.ceil(rect.bottom));
        if (right <= left || bottom <= top) return;
        int[] pixels = new int[(right-left)*(bottom-top)]; bitmap.getPixels(pixels,0,right-left,left,top,right-left,bottom-top);
        for (int i=0;i<pixels.length;i++) { int color=pixels[i]; pixels[i]=Color.argb(Color.alpha(color),255-Color.red(color),255-Color.green(color),255-Color.blue(color)); }
        bitmap.setPixels(pixels,0,right-left,left,top,right-left,bottom-top);
    }

    private Bitmap yuvToBitmap(ImageProxy image) {
        int w=image.getWidth(), h=image.getHeight();
        ImageProxy.PlaneProxy yPlane=image.getPlanes()[0], uPlane=image.getPlanes()[1], vPlane=image.getPlanes()[2];
        ByteBuffer yBuf=yPlane.getBuffer(), uBuf=uPlane.getBuffer(), vBuf=vPlane.getBuffer();
        int yRow=yPlane.getRowStride(), uvRow=uPlane.getRowStride(), yPix=yPlane.getPixelStride(), uvPix=uPlane.getPixelStride();
        byte[] out=new byte[w*h*4]; int k=0;
        for(int row=0;row<h;row++) for(int col=0;col<w;col++) {
            int yy=yBuf.get(row*yRow+col*yPix)&0xff;
            int uu=(uBuf.get((row/2)*uvRow+(col/2)*uvPix)&0xff)-128;
            int vv=(vBuf.get((row/2)*vPlane.getRowStride()+(col/2)*vPlane.getPixelStride())&0xff)-128;
            int r=(int)(yy+1.402*vv), g=(int)(yy-0.344136*uu-0.714136*vv), b=(int)(yy+1.772*uu);
            out[k++]=(byte)0xff; out[k++]=(byte)clamp(r); out[k++]=(byte)clamp(g); out[k++]=(byte)clamp(b);
        }
        int[] pixels=new int[w*h]; for(int i=0,j=0;i<pixels.length;i++) { int a=out[j++]&255, r=out[j++]&255, g=out[j++]&255, b=out[j++]&255; pixels[i]=(a<<24)|(r<<16)|(g<<8)|b; }
        return Bitmap.createBitmap(pixels,w,h,Bitmap.Config.ARGB_8888);
    }
    private int clamp(int v) { return Math.max(0,Math.min(255,v)); }
    @Override protected void onDestroy() { super.onDestroy(); if(cameraExecutor!=null) cameraExecutor.shutdown(); if(detector!=null) detector.close(); }
}
