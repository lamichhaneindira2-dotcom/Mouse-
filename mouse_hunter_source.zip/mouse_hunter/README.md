# Mouse Hunter (Android source project)

A starter Android app with:
- CameraX live frame capture using the phone's built-in rear camera.
- TensorFlow Lite Task Vision object detection using an EfficientDet-Lite0 COCO model.
- Mouse-only negative-color inversion when the model labels an object as `mouse`.
- A clearly labeled *simulated* wall-vision screen.
- An external-sensor demo toggle that explains real hardware is required.

## Important limitations

1. A phone camera cannot see through a solid wall. The wall screen is an illustration, not a real detection result.
2. Color inversion is a visual effect, not thermal or night vision. The camera needs enough light.
3. AI can miss a mouse or mistake another object for one. Treat it as an aid, not proof.
4. The external sensor toggle is UI only. Actual sensor support needs a specific compatible sensor, connection method (often Bluetooth LE), and its documented data protocol.
5. The app only detects visible objects in the camera frames. It does not include any trapping or killing mechanism.

## Build on a computer with Android Studio

1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open the `mouse_hunter` folder as an existing project.
3. Let Gradle sync and download dependencies.
4. Connect an Android phone with USB debugging enabled, or use an emulator with camera support.
5. Run the `app` configuration. Approve camera permission.
6. On first launch, the app attempts to download the public TensorFlow Lite EfficientDet-Lite0 metadata model over HTTPS into its private app storage. An internet connection is required for this first download. If the model endpoint is unavailable, the camera screen still opens but AI detection won't work; see manual model note below.

## Manual model fallback

If the automatic model download fails, download the TensorFlow Lite Task Vision EfficientDet-Lite0 detection model from the official TensorFlow model hosting page and save it as `mouse_detector.tflite` in the app's private files is not directly accessible. Easiest is to retry with internet enabled and reinstall/reopen the app. Do not rename an arbitrary model: the app expects a Task Vision object-detection model with metadata and COCO labels.

## How it works

- CameraX produces frames at about 640×480.
- TensorFlow Lite Task Vision runs object detection.
- Only detections whose label contains `mouse` are inverted and outlined.
- Wall mode replaces the camera frame with a static illustration marked as simulated.

## Project details

- Language: Java
- Minimum Android version: Android 8.0 (API 26)
- Target SDK: 35
- Dependencies: CameraX, AppCompat, TensorFlow Lite Task Vision

This is a source project, not a prebuilt APK. Build it in Android Studio to create the APK.
